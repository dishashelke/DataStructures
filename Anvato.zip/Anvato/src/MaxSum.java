
public class MaxSum {
	
	public static int maxSequenceSum(int[] array) {
		int localMax = array[0];
		int globalMax = array[0];
		for (int current: array){
			if (localMax > current) {
				localMax +=  current;
			}
			else {
				localMax =  current;
			}
			if (globalMax < localMax)
				globalMax = localMax;
		}
		return globalMax;
	}

	public static void main(String[] args) {
		int[] array = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
		System.out.print(maxSequenceSum(array));
	}

}
